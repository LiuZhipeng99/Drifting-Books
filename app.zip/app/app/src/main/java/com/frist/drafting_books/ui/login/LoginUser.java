package com.frist.drafting_books.ui.login;

public class LoginUser{
    public String n;
    public String password;
    public LoginUser(String n,String password){
        this.n = n;
        this.password = password;
    }

}