package com.frist.drafting_books.ui.login;

public class LoginModel {
}
