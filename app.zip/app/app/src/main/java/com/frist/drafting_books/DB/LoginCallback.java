package com.frist.drafting_books.DB;

import java.util.List;

import cn.leancloud.AVObject;

public interface LoginCallback {
    void Success();
    void Fail();
}
