package com.frist.drafting_books.DB;

public interface updateCallback {
    void Success();
    void Fail();
}
