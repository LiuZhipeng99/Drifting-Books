package com.frist.drafting_books.DB;

public interface SignUpCallback {
    void Success();
    void Fail();
}
